# Botpress Benchmark

##How to run

Botpress has to be running

```
yarn
yarn start
```
