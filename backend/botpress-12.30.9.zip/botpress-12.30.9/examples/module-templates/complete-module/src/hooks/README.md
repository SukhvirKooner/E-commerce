## Hooks

Every time the server is started, Hooks that you put in this folder will be copied in the `data/global/hooks/complete-module/HOOK_TYPE/` folder.
They will overwrite existing files only if they haven't been edited manually.

Check the documentation for more information about [Hooks](https://botpress.com/docs/build/code#hooks)
