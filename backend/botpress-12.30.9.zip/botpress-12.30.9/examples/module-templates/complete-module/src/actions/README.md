## Actions

Every time the server is started, Actions that you put in this folder will be copied in the `data/global/actions/complete-module/` folder.
They will overwrite existing files only if they haven't been edited manually.

Actions added this way will be available on the flow editor using `complete-module/your-action-name`

Check the documentation for more information about [Actions](https://botpress.com/docs/build/code#actions)
