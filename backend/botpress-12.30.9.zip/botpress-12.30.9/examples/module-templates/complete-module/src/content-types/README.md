## Content-Types

Every time the server is started, Content-types that you put in this folder will be copied in the `data/global/content-types/complete-module/` folder.
They will overwrite existing files only if they haven't been edited manually.

The name of your content types must be unique throughout the server

Check the documentation for more information about [Content Types](http://localhost:3001/docs/next/build/content)
