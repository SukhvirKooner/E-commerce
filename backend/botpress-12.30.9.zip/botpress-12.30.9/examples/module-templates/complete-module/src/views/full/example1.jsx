import React from 'react'

export class ExampleComponent1 extends React.Component {
  render() {
    return null
  }
}
