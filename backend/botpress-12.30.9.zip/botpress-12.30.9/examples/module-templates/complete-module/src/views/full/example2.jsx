import React from 'react'

export class ExampleComponent2 extends React.Component {
  render() {
    return null
  }
}
