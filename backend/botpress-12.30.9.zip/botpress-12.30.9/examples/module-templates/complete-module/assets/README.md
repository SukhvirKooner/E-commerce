## Assets

Every time the server is started, all the content of this folder will be copied in the `assets/modules/complete-module/` folder.
They will overwrite existing files.

Beware: This is a little different from actions and hooks, since they will be replaced even if you edit them.

## WARNING

Every file in this folder will be publicly available for unauthenticated users.
Only front-end bundles, images, css, etc. should be in this folder.
