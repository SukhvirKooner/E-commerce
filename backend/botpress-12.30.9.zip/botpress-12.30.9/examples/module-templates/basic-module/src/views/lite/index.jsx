import React from 'react'

export class LiteView extends React.Component {
  render() {
    return null
  }
}
