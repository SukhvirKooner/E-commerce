module.exports = {
  copyFiles: ['src/bot-templates/**']
}
