import React from 'react'

export default class MyMainView extends React.Component {
  render() {
    return null
  }
}
