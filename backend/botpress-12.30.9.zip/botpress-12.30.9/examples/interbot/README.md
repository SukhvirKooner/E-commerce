# Interbot Communication

This is an example of interbot communication. Copy these these files in your `<data>` directory, update your `workspaces.json` with the bot names and restart your Botpress Server.

> **Warning**: this may overwrite some of your bots, you should copy/paste those files in a fresh installation of Botpress Server.
