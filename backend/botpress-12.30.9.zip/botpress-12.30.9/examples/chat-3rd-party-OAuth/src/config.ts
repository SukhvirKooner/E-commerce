export interface Config {
  enabled: boolean
  apiKey: string
  apiSecret: string
}
