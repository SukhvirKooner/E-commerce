import React from 'react'

export default class MyModule extends React.Component {
  render() {
    return null
  }
}
