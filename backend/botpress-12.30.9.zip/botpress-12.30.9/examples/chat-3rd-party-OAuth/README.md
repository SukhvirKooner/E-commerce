# 3rd party OAuth in conversation example

Here we will use Twitter as OAuth provider to authenticate the user in a chat session, same concepts can be applied with other providers. For step by step explanations, head to the [associated tutorial](https://botpress.com/docs/tutorials/3rd-party-OAuth/)
