module.exports = {
  '*': 'node ./build/lint-staged-filesize.js'
}
