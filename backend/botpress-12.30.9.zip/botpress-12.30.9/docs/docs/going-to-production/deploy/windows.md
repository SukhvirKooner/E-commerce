---
id: windows
title: Windows (Bare Metal)
---

--------------------
