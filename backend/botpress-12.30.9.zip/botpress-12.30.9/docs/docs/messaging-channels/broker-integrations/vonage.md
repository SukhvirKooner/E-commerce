---
id: vonage
title: Vonage
---

---

import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

import VonageLocal from './vonage/local.md'

:::note
Currently, only WhatsApp is supported on this channel.
:::

<VonageLocal/>
