---
id: slack
title: Slack
---

---

import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

import SlackLocal from './slack/local.md'

<SlackLocal/>