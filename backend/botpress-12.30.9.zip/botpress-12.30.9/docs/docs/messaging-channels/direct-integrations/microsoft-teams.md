---
id: microsoft-teams
title: Microsoft Teams
---

---

import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

import TeamsLocal from './teams/local.md'

<TeamsLocal/>
  