---
id: telegram
title: Telegram
---

import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

import TelegramLocal from './telegram/local.md'

<TelegramLocal/>