Make sure these checkboxes are checked before raising an issue, thank you!

- [] Make sure your NodeJS version is `12.18.1`
- [] Search the [documentation](https://botpress.com/docs)
- [] Search the [help portal](https://forum.botpress.com/)

Please also fill in these fields:

---

- I am running: `official binary | from nodejs | from docker`
- My OS is: `windows, osx, ubuntu, debian, fedora, centos`
