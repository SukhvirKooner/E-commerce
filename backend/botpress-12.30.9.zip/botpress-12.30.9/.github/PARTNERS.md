## Botpress Partners

Botpress Partners is a list of agencies who can help you build your next conversational assistant.

| Agency Name                                     | Location                            |
| ----------------------------------------------- | ----------------------------------- |
| [Okam](https://okam.ca/)                        | Montreal, Canada                    |
| [Lampyon](https://www.lampyon.com/)             | Toronto, Canada & Budapest, Hungary |
| [Smile](https://www.smile.eu)                   | Asnières-sur-Seine, France          |
| [Solvative](https://solvative.com/)             | Kansas City, KS & New York, NY, USA |
| [ZeroBulb](https://www.zerobulb.com)            | Kerala, India                       |
| [Tasqat](https://www.tasqat.com)                | Dubai, United Arab Emirates         |
| [Creative Melon](https://creativemelon.co.za)   | Johannesburg, South Africa          |
| [PaperGo](https://www.papergo.io)               | Patras, Greece                      |
| [BotArtisanz](http://botartisanz.com/)          | Kerala, India                       |
| [DevSamurai](https://www.devsamurai.com/)       | Tokyo, Japan                        |
| [Teplar Solutions](https://www.teplar.com)      | Coimbatore, Tamil Nadu, India       |
| [SabanaTech](https://www.sabanatech.com)        | San José, Costa Rica, Latin America |
| [Specloid Solutions](https://www.specloid.com/) | Bengaluru, Karnataka, India         |

_If you are an agency and would like to be on this list, please clone the repository & add your agency to the list in the README.md. Then, you can create a pull request on the repository and we'll make sure to review and merge your PR swiftly._
